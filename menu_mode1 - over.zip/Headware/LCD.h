#ifndef _LCD_H
#define _LCD_H

void LCD_Init(void);
	
#endif
