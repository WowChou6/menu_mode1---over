#ifndef _EXTI_H
#define _EXTI_H

extern int cnt1,cnt2;

void Exti_Init(void);


#endif
