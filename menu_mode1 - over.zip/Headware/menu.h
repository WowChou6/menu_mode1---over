#ifndef _MENU_H
#define _MENU_H

extern int key0,key1;

int menu1(void);
int mode1(void);
int mode2(void);
int mode3(void);
int mode4(void);
#endif 
