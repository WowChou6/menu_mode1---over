#ifndef _SERIAL_H
#define _SERIAL_H

void Serial_Init(void);
void Serial_SendData(uint16_t Byte);

#endif
