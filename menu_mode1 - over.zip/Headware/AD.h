#ifndef _AD_H
#define _AD_H

void AD_Init(void);
uint16_t AD_GetValue(void);

#endif
