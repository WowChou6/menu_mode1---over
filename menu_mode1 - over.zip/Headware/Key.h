#ifndef _KEY_H
#define _KEY_H
#define key

extern int key0,key1;

void Key_Init(void);
uint8_t Key0_read(void);
uint8_t Key1_read(void);

#endif
