#ifndef _SPEAKER_H
#define _SPEAKER_H

void Speaker_Init(void);
void Speak(void);

#endif
